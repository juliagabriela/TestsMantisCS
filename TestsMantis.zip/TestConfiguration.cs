﻿namespace $safeprojectname$
{
    public class TestConfiguration
    {
        public BrowserType Browser { get { return BrowserType.Firefox; } }
        // public BrowserType Browser { get { return BrowserType.Chrome; } }
        public string BaseURL { get { return "http://mantis-prova.base2.com.br/"; } }
    }
}
