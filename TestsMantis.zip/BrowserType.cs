﻿namespace $safeprojectname$
{
    public enum BrowserType
    {
        Firefox,
        Chrome
    }
}
